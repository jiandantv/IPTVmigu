(function() {
  document.addEventListener('DOMContentLoaded', function() {
    const videoPlayer = document.getElementById('videoPlayer');
    let isQualityEnhanced = true;
    let isInitialized = false;
    function createQualityControl() {
      if (document.getElementById('qualityControl')) return;
      const controls = document.getElementById('controls');
      const volumeContainer = document.querySelector('.volume-container');
      if (!controls || !volumeContainer) return;
      const qualityContainer = document.createElement('div');
      qualityContainer.id = 'qualityControl';
      qualityContainer.className = 'quality-container';
      qualityContainer.style.cssText = `
        display: flex;
        align-items: center;
        margin-left: 10px;
        cursor: pointer;
      `;
      const toggleBtn = document.createElement('button');
      toggleBtn.id = 'qualityToggleBtn';
      toggleBtn.className = 'quality-toggle-btn';
      toggleBtn.title = '切换画质增强';
      const qualityDot = document.createElement('span');
      qualityDot.className = 'quality-dot-indicator';
      qualityDot.style.cssText = `
        display: block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #4CAF50;
        transition: all 0.3s ease;
        box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3);
      `;
      toggleBtn.appendChild(qualityDot);
      toggleBtn.style.cssText = `
        background: none;
        border: none;
        cursor: pointer;
        padding: 6px;
        opacity: 0.9;
        transition: all 0.2s;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
      `;
      qualityContainer.appendChild(toggleBtn);
      volumeContainer.parentNode.insertBefore(qualityContainer, volumeContainer.nextSibling);
      return { container: qualityContainer, button: toggleBtn, dot: qualityDot };
    }
    function createQualityStyles() {
      const styleId = 'quality-enhancement-styles';
      if (document.getElementById(styleId)) return;
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
        /* 画质增强效果 - 保持不变 */
        .quality-enhanced .video-container::before {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          width: 100% !important;
          height: 100% !important;
          backdrop-filter: blur(0.6px) !important;
          opacity: 0.18 !important;
          pointer-events: none !important;
          z-index: 1 !important;
          box-shadow: 
            inset 0 0 40px 15px rgba(0, 0, 0, 0.25),
            inset 0 0 80px 30px rgba(0, 0, 0, 0.1) !important;
        }
        .quality-enhanced .video-container::after {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          right: 0 !important;
          width: 100px !important;
          height: 100% !important;
          background: linear-gradient(
            to left,
            rgba(0, 0, 0, 0.4) 0%,
            rgba(0, 0, 0, 0.15) 30%,
            transparent 70%
          ) !important;
          backdrop-filter: blur(1.2px) !important;
          pointer-events: none !important;
          z-index: 2 !important;
          opacity: 0.3 !important;
        }
        .quality-enhanced #videoPlayer {
          filter: 
            contrast(1.04)
            brightness(1.02)
            saturate(1.02)
            drop-shadow(0 0 0.5px rgba(255,255,255,0.15)) !important;
          -webkit-filter: 
            contrast(1.04)
            brightness(1.02)
            saturate(1.02)
            drop-shadow(0 0 0.5px rgba(255,255,255,0.15)) !important;
          transform: translate3d(0, 0, 0) !important;
          -webkit-transform: translate3d(0, 0, 0) !important;
        }
        .quality-enhanced.enhanced-mode .video-container::before {
          backdrop-filter: blur(0.8px) !important;
          opacity: 0.25 !important;
        }
        .quality-enhanced.enhanced-mode .video-container::after {
          backdrop-filter: blur(1.5px) !important;
          opacity: 0.4 !important;
        }
        .quality-enhanced.enhanced-mode #videoPlayer {
          filter: 
            contrast(1.06)
            brightness(1.03)
            saturate(1.03)
            drop-shadow(0 0 0.8px rgba(255,255,255,0.2)) !important;
          -webkit-filter: 
            contrast(1.06)
            brightness(1.03)
            saturate(1.03)
            drop-shadow(0 0 0.8px rgba(255,255,255,0.2)) !important;
        }
        /* 质量控制点样式 */
        .quality-dot-indicator {
          display: block !important;
          width: 12px !important;
          height: 12px !important;
          border-radius: 50% !important;
          transition: all 0.3s ease !important;
        }
        /* 开启状态 - 绿色发光 */
        .quality-enhanced .quality-dot-indicator {
          background: #4CAF50 !important;
          box-shadow: 
            0 0 0 2px rgba(76, 175, 80, 0.3),
            0 0 6px rgba(76, 175, 80, 0.8) !important;
          animation: qualityPulse 2s infinite !important;
        }
        /* 关闭状态 - 灰色 */
        body:not(.quality-enhanced) .quality-dot-indicator {
          background: #9CA3AF !important;
          box-shadow: 
            0 0 0 2px rgba(156, 163, 175, 0.3),
            0 0 4px rgba(156, 163, 175, 0.4) !important;
        }
        @keyframes qualityPulse {
          0% { box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3), 0 0 6px rgba(76, 175, 80, 0.8); }
          50% { box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.4), 0 0 10px rgba(76, 175, 80, 1); }
          100% { box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3), 0 0 6px rgba(76, 175, 80, 0.8); }
        }
        /* 按钮悬停效果 */
        .quality-toggle-btn:hover .quality-dot-indicator {
          transform: scale(1.2);
        }
        .quality-toggle-btn:active .quality-dot-indicator {
          transform: scale(0.9);
        }
        /* 通知样式 */
        .quality-notification {
          position: fixed !important;
          top: 60px !important;
          left: 50% !important;
          transform: translateX(-50%) !important;
          background: rgba(0, 100, 0, 0.9) !important;
          color: white !important;
          padding: 8px 16px !important;
          border-radius: 4px !important;
          font-size: 13px !important;
          z-index: 9999 !important;
          animation: fadeInOut 2s ease-in-out !important;
          pointer-events: none !important;
          white-space: nowrap !important;
        }
        .quality-notification.closed {
          background: rgba(255, 68, 68, 0.9) !important;
        }
        @keyframes fadeInOut {
          0% { opacity: 0; transform: translate(-50%, -10px); }
          10% { opacity: 1; transform: translate(-50%, 0); }
          90% { opacity: 1; transform: translate(-50%, 0); }
          100% { opacity: 0; transform: translate(-50%, -10px); }
        }
      `;
      document.head.appendChild(style);
    }
    function applyQualityEnhancement() {
      console.log('✅ 启用画质增强');
      document.body.classList.add('quality-enhanced');
      document.body.classList.add('enhanced-mode');
      //const button = document.getElementById('qualityToggleBtn');
      //if (button) {
        //button.title = '画质增强已开启 (点击关闭)';
      //}
      showQualityNotification('画质增强已开启', false);
    }
    function removeQualityEnhancement() {
      console.log('🔇 关闭画质增强');
      document.body.classList.remove('quality-enhanced');
      document.body.classList.remove('enhanced-mode');
      //const button = document.getElementById('qualityToggleBtn');
      //if (button) {
        //button.title = '画质增强已关闭 (点击开启)';
      //}
      showQualityNotification('画质增强已关闭', true);
    }
    function showQualityNotification(message, isClosed) {
      const oldNotification = document.querySelector('.quality-notification');
      if (oldNotification) oldNotification.remove();
      const notification = document.createElement('div');
      notification.className = `quality-notification ${isClosed ? 'closed' : ''}`;
      notification.textContent = message;
      document.body.appendChild(notification);
      setTimeout(() => {
        if (notification.parentNode) notification.parentNode.removeChild(notification);
      }, 2000);
    }
    function initQualityEnhancement() {
      if (isInitialized) return;
      isInitialized = true;
      createQualityStyles();
      const controls = createQualityControl();
      if (!controls) return;
      try {
        const saved = localStorage.getItem('videoQualityEnhanced');
        if (saved !== null) isQualityEnhanced = saved === 'true';
      } catch (e) {
        console.warn('无法加载用户偏好:', e);
      }
      controls.button.addEventListener('click', function() {
        isQualityEnhanced = !isQualityEnhanced;
        if (isQualityEnhanced) {
          applyQualityEnhancement();
        } else {
          removeQualityEnhancement();
        }
        try {
          localStorage.setItem('videoQualityEnhanced', isQualityEnhanced);
        } catch (e) {
          console.warn('无法保存用户偏好:', e);
        }
      });
      if (isQualityEnhanced) {
        applyQualityEnhancement();
      } else {
        removeQualityEnhancement();
      }
      console.log('🎯 画质增强系统初始化完成');
    }
    setTimeout(initQualityEnhancement, 800);
  });
})();